Source code related to my [YouTube Channel](https://www.youtube.com/channel/UCTSDQ3BAZfrweD2nBMwJEpQ)

After downloading the code, open the browser on the index.html file.